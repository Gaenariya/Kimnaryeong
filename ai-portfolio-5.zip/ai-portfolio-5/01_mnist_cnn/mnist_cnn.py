# 01. MNIST 손글씨 숫자 분류 (CNN, Keras)
# Google Colab에 그대로 복사해서 셀 단위(# %%)로 실행하면 됩니다.

# %%
import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt

# %% 데이터 불러오기
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
x_train = x_train.reshape(-1, 28, 28, 1).astype("float32") / 255.0
x_test = x_test.reshape(-1, 28, 28, 1).astype("float32") / 255.0

# %% 샘플 이미지 확인
plt.imshow(x_train[0].squeeze(), cmap="gray")
plt.title(f"label: {y_train[0]}")
plt.show()

# %% 모델 구성
model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation="relu", input_shape=(28, 28, 1)),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation="relu"),
    layers.MaxPooling2D((2, 2)),
    layers.Flatten(),
    layers.Dense(64, activation="relu"),
    layers.Dropout(0.3),
    layers.Dense(10, activation="softmax"),
])

model.compile(optimizer="adam",
              loss="sparse_categorical_crossentropy",
              metrics=["accuracy"])
model.summary()

# %% 학습
history = model.fit(x_train, y_train, epochs=5, batch_size=128,
                     validation_split=0.1)

# %% 평가
test_loss, test_acc = model.evaluate(x_test, y_test)
print(f"Test accuracy: {test_acc:.4f}")

# %% 학습 곡선 시각화
plt.plot(history.history["accuracy"], label="train_acc")
plt.plot(history.history["val_accuracy"], label="val_acc")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.legend()
plt.show()

# %% 예측 예시
import numpy as np
idx = 0
pred = model.predict(x_test[idx:idx+1])
print("예측:", np.argmax(pred), " 정답:", y_test[idx])
