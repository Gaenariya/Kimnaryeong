# 02. YOLOv8 객체 탐지 (Ultralytics)
# Google Colab에 그대로 복사해서 셀 단위(# %%)로 실행하면 됩니다.

# %% 패키지 설치 (Colab 첫 실행 시 필요)
!pip install ultralytics -q

# %% 라이브러리 불러오기
from ultralytics import YOLO
import matplotlib.pyplot as plt
import cv2

# %% 사전학습된 YOLOv8 모델 불러오기 (nano 버전, 가볍고 빠름)
model = YOLO("yolov8n.pt")

# %% 샘플 이미지 다운로드 (직접 이미지를 업로드해도 됩니다)
!wget -q -O sample.jpg https://ultralytics.com/images/bus.jpg

# %% 객체 탐지 실행
results = model("sample.jpg")

# %% 결과 시각화
result_img = results[0].plot()  # BGR numpy array
result_img = cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB)

plt.figure(figsize=(10, 10))
plt.imshow(result_img)
plt.axis("off")
plt.show()

# %% 탐지된 객체 정보 출력
for box in results[0].boxes:
    cls_id = int(box.cls[0])
    cls_name = model.names[cls_id]
    conf = float(box.conf[0])
    print(f"{cls_name}: {conf:.2f}")

# %% (선택) 내 이미지로 직접 테스트하기 - Colab 파일 업로드
from google.colab import files
uploaded = files.upload()  # 이미지 파일 선택

for fname in uploaded.keys():
    my_results = model(fname)
    my_img = cv2.cvtColor(my_results[0].plot(), cv2.COLOR_BGR2RGB)
    plt.figure(figsize=(10, 10))
    plt.imshow(my_img)
    plt.axis("off")
    plt.show()
